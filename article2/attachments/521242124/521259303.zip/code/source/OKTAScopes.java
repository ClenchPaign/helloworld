

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.codehaus.jackson.map.ObjectMapper;
import com.softwareag.util.IDataMap;
// --- <<IS-END-IMPORTS>> ---

public final class OKTAScopes

{
	// ---( internal utility methods )---

	final static OKTAScopes _instance = new OKTAScopes();

	static OKTAScopes _newInstance() { return new OKTAScopes(); }

	static OKTAScopes _cast(Object o) { return (OKTAScopes)o; }

	// ---( server methods )---




	public static final void OKTAScopeManager (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(OKTAScopeManager)>> ---
		// @sigtype java 3.5
		String action = IDataUtil.getString(pipeline.getCursor(), "action");
		IData authInfo = IDataUtil.getIData(pipeline.getCursor(), "authorizationInfo");
		String token = IDataUtil.getString(authInfo.getCursor(), "token");
		String scopeName = IDataUtil.getString(pipeline.getCursor(), "scopeName");
		System.out.println(pipeline);
		
		if("create".equals(action)){
			try {
				String scopeId = getScopeId(pipeline, scopeName, token);
				if(scopeId != null){
					updateScope(pipeline, scopeId, token);
				}else {
					createScope(pipeline, token);
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static String getEndPoint(IData pipeline, String endpointType){
		IData endpoints = IDataUtil.getIData(pipeline.getCursor(), "endpoints");
		Map<String, Object> endpointsMap = (Map)IDataUtil.get(endpoints.getCursor(), "endpoints");
		System.out.println("Endpoints " + endpointsMap);
		
		Map<String,Object> endpointMap = (Map)endpointsMap.get(endpointType);
		System.out.println(endpointMap);
		
		String url = (String)endpointMap.get("endpoint");
		return url;
	}
	
	public static void updateScope(IData pipeline, String scopeId, String token) throws Exception{
		String scopeCreateUrl = getEndPoint(pipeline, "SCOPE_UPDATE");
		scopeCreateUrl = scopeCreateUrl.replaceAll("\\{scope_id\\}", scopeId);
		Map<String, String> payload = new HashMap<>();
	    payload.put("name", IDataUtil.getString(pipeline.getCursor(), "scopeName"));
	    payload.put("description", "Updated through ESB " + IDataUtil.getString(pipeline.getCursor(), "scopeDescription"));
	    payload.put("metadataPublish", "ALL_CLIENTS");
	        
	    ObjectMapper objectMapper = new ObjectMapper();
		IData payloadIData;
		
		payloadIData = IDataFactory.create(
		        new Object[][] { 
		        					{ "url", scopeCreateUrl },
		        					{ "method", "PUT" },
		        					{ "loadAs", "bytes" },
		        					{ "headers", IDataFactory.create(new Object[][] {
		        													{ "Accept", "application/json" },
		        													{ "Content-type", "application/json" },
		        													{ "Authorization", "SSWS " + token }
		    													})},
		        					{ "data", IDataFactory.create(new Object[][] {
		        																	{ "bytes", objectMapper.writeValueAsBytes(payload)}})
		    														}});
		
		System.out.println(payloadIData);
		Service.doInvoke("pub.client", "http", payloadIData);
	}
	
	
	public static void createScope(IData pipeline, String token) throws Exception{
		String scopeCreateUrl = getEndPoint(pipeline, "SCOPE_CREATE");
		Map<String, String> payload = new HashMap<>();
	    payload.put("name", IDataUtil.getString(pipeline.getCursor(), "scopeName"));
	    payload.put("description", "Created through ESB " + IDataUtil.getString(pipeline.getCursor(), "scopeDescription"));
	        
	    ObjectMapper objectMapper = new ObjectMapper();
		IData payloadIData;
		
		payloadIData = IDataFactory.create(
		        new Object[][] { 
		        					{ "url", scopeCreateUrl },
		        					{ "method", "POST" },
		        					{ "loadAs", "bytes" },
		        					{ "headers", IDataFactory.create(new Object[][] {
		        													{ "Accept", "application/json" },
		        													{ "Content-type", "application/json" },
		        													{ "Authorization", "SSWS " + token }
		    													})},
		        					{ "data", IDataFactory.create(new Object[][] {
		        																	{ "bytes", objectMapper.writeValueAsBytes(payload)}})
		    														}});
		
		System.out.println(payloadIData);
		Service.doInvoke("pub.client", "http", payloadIData);
	}
	public static String getScopeId(IData pipeline, String scopeName, String token) throws Exception{
		String url = getEndPoint(pipeline, "SCOPE_READ");
		IData payloadIData = IDataFactory.create(
		        new Object[][] { 
		        					{ "url", url },
		        					{ "method", "GET" },
		        					{ "loadAs", "bytes" },
		        					{ "headers", IDataFactory.create(new Object[][] {
		        													{ "Accept", "application/json" },
		        													{ "Content-type", "application/json" },
		        													{ "Authorization", "SSWS " + token }
		    													})}});
	
		IDataMap output = new IDataMap(Service.doInvoke("pub.client", "http", payloadIData));
		byte[] result = (byte[]) output.getNested("body", "bytes");
		ObjectMapper mapper = new ObjectMapper();
	    try {
	        Map<String, Object>[] allScopes = mapper.readValue(result, Map[].class);
	        String scopeId = null;
	        for(Map<String, Object> scope: allScopes){
	            if(scopeName.equals(scope.get("name"))){
	                scopeId = (String)scope.get("id");
	                break;
	            }
	        }
	        return scopeId;	
	        
	        
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	   	
	    return null;
	}
	// --- <<IS-END-SHARED>> ---
}

